function [mps] = detect_matches(image, nb_r, nb_c, target, threshold)
    mps = [];
    rd = floor(nb_r/2);
    cd = floor(nb_c/2);
    % for each pixel
    for row=rd+1:size(image,1)-rd
        for col=cd+1:size(image,2)-cd
            % assemble a neighborhood
            nb = image(row-rd:row+rd,col-cd:col+cd);
            % check for match
            match = compare_nb(nb, target, threshold);
            if match == true
                mps = [mps,[row;col]];
            end
        end
    end
end