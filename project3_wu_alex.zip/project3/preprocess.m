clear all; close all;

images = [];
for i=10:39
    image = imread(append("./images/", int2str(i)), "pgm");
    images(:,:,i-9) = image;
end

% implement the following functions
% detect_matches
%       take an image, nb size, and search target and return 
%       list of matching centers
% closest_center
%       take list of matching centers and center and choose the closest
%       center
% compare_nb
%       take two neighborhoods and compare them for similarity against a
%       threshold

% Initialize by manually choosing match regions for each visible corner of
% polyhedron
% Initialize velocity states to 0
% Initialize position states to positions in first image
% Enter main tracking loop
%   predict next states based on previous prediction
%   load next image
%   for each landmark, detect matches and find correspondence
%   adjust state prediction for actual prediction

nb_r = 17;
nb_c = 17;
rd = floor(nb_r/2);
cd = floor(nb_c/2);

% pull out neighborhoods for corners 1-7 just on observation
% (83,256)
centers = [[79;119],[89;118],[157;123],[92;233],[83;256],[79;273],[164;274]];
% array of neighborhoods corresponding to corners
nb = {};
for n=1:size(centers, 2)
    row = centers(1,n);
    col = centers(2,n);
    nb{1,n} = images(row-rd:row+rd, col-cd:col+cd, 1);
end

% Detect matches in first image
% false positives start occurring at around 20000
threshold = 15000;
figure(3);
colormap(gray);
hold on;
image1 = images(:, :, 1);
imsurf(image1,[0,0,0],[0,0,1],[1,0,0],[]);
for i=1:size(nb,2)
    matches = detect_matches(image1, nb_r, nb_c, nb{1,i}, threshold);
    scatter(matches(2,:), -1*matches(1,:), 'red', 'x');
end

% save initial positions of corners
save("corners_pos.mat", "centers");
% save corners defined as neighborhood cell arrays
save("corners.mat", "nb");
% save image matrices
save("images.mat", "images");