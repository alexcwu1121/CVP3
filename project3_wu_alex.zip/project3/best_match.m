function [best] = best_match(image, nb_r, nb_c, target)
    rd = floor(nb_r/2);
    cd = floor(nb_c/2);
    
    best = [0;0];
    best_diff = 1*10^12;
    % for each pixel
    for row=rd+1:size(image,1)-rd
        for col=cd+1:size(image,2)-cd
            % assemble a neighborhood
            nb = image(row-rd:row+rd,col-cd:col+cd);
            % check for match
            match_diff = sum((nb - target).^2, 'all');
            if match_diff < best_diff
                best = [row;col];
                best_diff = match_diff;
            end
        end
    end
end