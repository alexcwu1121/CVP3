function [match] = compare_nb(nb1, nb2, threshold)
    diff = sum((nb1 - nb2).^2, 'all');
    if diff < threshold
        match = true;
    else
        match = false;
    end
end