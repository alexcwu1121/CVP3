clear all; close all;

images_f = load("images.mat");
images = images_f.images;

cov_vec_f = load("cov_vec.mat");
cov_vec = cov_vec_f.cov_vec;

pos_vec_f = load("pos_vec.mat");
pos_vec = pos_vec_f.pos_vec;

cov_trace = [];
figure(1);
for i = 1:30
    %hold on;
    %colormap(gray);
    %imsurf(images(:,:,i),[0,0,0],[0,0,1],[1,0,0],[]);
    traces = zeros(7,1);
    for j = 1:7
        %posv = pos_vec{1,j};
        %pos = posv(:,i);
        %scatter([pos(2,1)], -1*[pos(1,1)], 'red', 'x');
        traces(j,1) = trace(cov_vec{i,j});
    end
	%pause(0.05);
	%M(i) = getframe;
    cov_trace = [cov_trace, traces];
end
%movie(M,5);

% save q and covs
% plot trace of covs over time
% writematrix(m,'M.csv');
figure(2);
hold on;
for i=1:7
    plot(1:30, cov_trace(i,:));
end
title("Error Covariance Traces over 30 Frames");
xlabel("Frames");
ylabel("Cov Trace");


for i=1:7
    pos_vert = pos_vec{1,i}';
    writematrix(pos_vert, append(append("pos",int2str(i)), ".csv"));
    
    cov_vert = [];
    for j=1:30
        cov_vert = [cov_vert, cov_vec{j,i}];
    end
    writematrix(cov_vert', append(append("cov",int2str(i)), ".csv"));
end