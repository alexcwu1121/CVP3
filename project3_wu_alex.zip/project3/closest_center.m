function [closest] = closest_center(target, centers)
    closest = centers(:,1);
    closest_d = norm(centers(:,1) - target);
    for i=2:size(centers,2)
        d = norm(centers(:,i) - target);
        if d < closest_d
            closest = centers(:,i);
            closest_d = d;
        end
    end
end