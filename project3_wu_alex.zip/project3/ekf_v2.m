% ekf.m
% Extended Kalman Filter implementation

classdef ekf_v2 < dynamicprops
    % dynamic state and covariances property to be added later
    
    % static properties include static transformation matrix, measurement
    % matrix
    properties (Access=private)
        % static props
        D % state propagation
        H % measurement matrix
        Q % process covariance
        R % measurement covariance
        
        % dynamic props
        % q: state vector of position and velocity
        % cov: error covariance
    end
    
    methods
        function obj = ekf_v2(D, H, Q, R)
            obj.D = D; % state propagation matrix
            obj.H = H; % measurement matrix
            obj.Q = Q; % process covariance
            obj.R = R; % measurement covariance
        end
        
        function [q] = get_q(obj)
            q = obj.q;
        end
        
        function [] = set_q(obj,q_new)
            obj.q = q_new;
        end
        
        function [cov] = get_cov(obj)
            cov = obj.cov;
        end
        
        function [] = set_cov(obj,cov_new)
            obj.cov = cov_new;
        end
        
        function [q_pred, cov_pred] = predict(obj)
            q_pred = obj.D*obj.q;
            cov_pred = obj.D*obj.cov*obj.D'+obj.Q;
        end
        
        function [q_pred,p_pred] = update(obj,q_pred,cov_pred,measure)
            % given some measurement, fuse measurement with predicted state
            
            % predicted state represented in measurement space
            z_diff = measure - obj.H*q_pred;
            
            K = cov_pred*obj.H'*inv(obj.H*cov_pred*obj.H'+obj.R);
            
            obj.q = q_pred + K*z_diff;
            ci = K*obj.H;
            obj.cov = (eye(size(ci,1))-ci)*cov_pred;
        end
    end
end