clear all; close all;

images_f = load("images.mat");
images = images_f.images;

corners_f = load("corners.mat");
corners = corners_f.nb;

corners_pos_f = load("corners_pos.mat");
corners_pos = corners_pos_f.centers;

D = [1,0,1,0;0,1,0,1;0,0,1,0;0,0,0,1];
H = [1,0,0,0;0,1,0,0];
Q = [16,0,0,0;0,16,0,0;0,0,4,0;0,0,0,4];
R = [4,0;0,4];
cov_init = [100,0,0,0;0,100,0,0;0,0,25,0;0,0,0,25];

% initialize 7 Kalman Filters
ekfs = cell(1,7);
% log positions for each corner
pos_vec = cell(1,7);
cov_vec = cell(1,7);
for i=1:size(ekfs,2)
    ekf = ekf_v2(D, H, Q, R);
    ekf.addprop('q');
    ekf.addprop('cov');
    % initialize velocity to zero
    % initialize cov to something large
    ekf.q = [corners_pos(:,i);0;0];
    ekf.cov = cov_init;
    ekfs{1,i} = ekf;
    pos_vec{1,i} = [corners_pos(:,i)];
    cov_vec{1,i} = cov_init;
end

% for each frame:
% predict and get dead reckoned q and covs
% measure (search region based on q and covs)
% update
% repeat
for i=2:30
    curr_image = images(:,:,i);
    % every kalman filter
    for f=1:7
        curr_ekf = ekfs{1,f};
        [q, cov] = curr_ekf.predict;
        [nb_r, nb_c] = search_cov(cov);
        rd = floor(nb_r/2);
        cd = floor(nb_c/2);
        % search region defined by q(1:2,1) and rd, cd for a match
        row = q(1,1);
        col = q(2,1);
        
        r1 = min([max([row-rd, 1]), size(curr_image, 1)]);
        r2 = min([max([row+rd, 1]), size(curr_image, 1)]);
        c1 = min([max([col-cd, 1]), size(curr_image, 2)]);
        c2 = min([max([col+cd, 1]), size(curr_image, 2)]);
        region = curr_image(r1:r2,c1:c2);
        
        % find matches
        nb_r_match = size(corners{1,f},1);
        nb_c_match = size(corners{1,f},2);
        match = best_match(region, nb_r_match, nb_c_match, corners{1,f});
        
        disp("row col before");
        disp([row;col]);
        disp("search window size");
        disp(rd);
        disp(cd);
        disp("row col in search window");
        disp(match);
        disp("final row col");
        
        match = match + [r1;c1];
        disp(match);
        
        % update kalman filter
        curr_ekf.update(q, cov, match);
        
        q_star = curr_ekf.get_q();
        cov_star = curr_ekf.get_cov();
        pos_vec{1,f} = [pos_vec{1,f}, q_star(1:2,1)];
        cov_vec{i,f} = cov_star;
    end
end

% save cov and q logs
save("cov_vec.mat", "cov_vec");
save("pos_vec.mat", "pos_vec");