function [rd, cd] = search_cov(cov)
    % generate dimensions of search range from covariance matrix
    ev = eig(cov(1:2,1:2));
    rd = 3*ev(1,1);
    cd = 3*ev(2,1);
end